README
======

5/24/2018
v1.0

CST 352 - Assignment 4 Handout
Pete's Solution

Launch SimpleShell.exe
When prompted, enter username "root"
Choose a password, then login again as root with the new password
Use the "help" command to see the list of available commands

NOTE:  The available commands represent as a significant amount of extra credit!
